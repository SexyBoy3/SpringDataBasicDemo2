package com.example.springdatabasicdemo.models;


import jakarta.persistence.*;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import java.math.BigDecimal;
import java.util.Set;

@Entity
public class Vehiclecar extends Vehicle{

    private int seats;
    protected Vehiclecar(){}

    public Vehiclecar(String type, String model, BigDecimal price, String fueltype, int seats) {
        super(type, model, price, fueltype);
        this.seats = seats;
    }

    public int getSeats() {return seats;}
    public void setSeats(int seats) {this.seats = seats;}

}
